# Cartographer 2 Locale System
All global locale files should go in here.

## More information
To create your own locale, take a look in the `en_us` locale file, or check out the [Github wiki](https://github.com/BananaPuncher714/Cartographer2/wiki/Locales).